import React, { useRef } from 'react'
import {Link} from 'react-router-dom'



function Signup() {
    let firstNameInputRef = useRef();
    let lastNameInputRef = useRef();
    let maleRadioInputRef = useRef();
    let femaleRadioInputRef = useRef();
    let selectInputRef = useRef();
    let ageInputRef = useRef();
    let emailInputRef = useRef();
    let passwordInputRef = useRef();
    let mobileNoInputRef = useRef();
    let profilePicInputRef = useRef();
    let resultParaInputRef = useRef();
    let selectedGender;
    let salutation;
    let maritalStatus;
   
    
  return (
    <div >
    <form className='container'>
    <h2 style = {{color:"blue",fontWeight:"bold"}}>Sign Up</h2>
    <div>
    <label>First Name</label>
    <input ref = {firstNameInputRef}/>
    </div>
    <div>
    <label>Last Name</label>
    <input ref = {lastNameInputRef}/>
    </div>
    <div>
    <label>Gender</label>
    <input ref = {maleRadioInputRef} type = "radio" name='gender' onChange={()=>{
      if(maleRadioInputRef.current.checked ==true){
        selectedGender = "male"

      }
    }}></input>
    <label style = {{width:"auto"}}>Male</label>
    <input ref = {femaleRadioInputRef} type = "radio" name='gender' onChange={()=>{
      if(femaleRadioInputRef.current.checked == true){
        selectedGender = "female"

      }
    }}/>
    <label style = {{width:"auto"}}>Female</label>
    </div>
    <div>
    <label>Marital Status</label>
    <input type = "radio" name = "status" onChange={(eventObj)=>{
      if(eventObj.target.checked == true){
        maritalStatus = "single"

      }

    }}/>
    <label style = {{width:"auto"}}>Single</label>
    <input type = "radio" name = "status" onChange={(eventObj)=>{
      if(eventObj.target.checked == true){
        maritalStatus = "married"

      }
    }}/>
    <label style = {{width:"auto"}}>Married</label>
    </div>
    <div>
    <select ref = {selectInputRef}>
    <option value="AP">Andhra Pradesh</option>
<option value="Arunachal Pradesh">Arunachal Pradesh</option>
<option value="Assam">Assam</option>
<option value="Bihar">Bihar</option>
<option value="Chhattisgarh">Chhattisgarh</option>
<option value="Goa">Goa</option>
<option value="Gujarat">Gujarat</option>
<option value="Haryana">Haryana</option>
<option value="HP">Himachal Pradesh</option>
<option value="Jharkhand">Jharkhand</option>
<option value="Karnataka">Karnataka</option>
<option value="Kerala">Kerala</option>
<option value="MP">Madhya Pradesh</option>
<option value="Maharashtra">Maharashtra</option>
<option value="Manipur">Manipur</option>
<option value="Meghalaya">Meghalaya</option>
<option value="Mizoram">Mizoram</option>
<option value="Nagaland">Nagaland</option>
<option value="Odisha">Odisha</option>
<option value="Punjab">Punjab</option>
<option value="Rajasthan">Rajasthan</option>
<option value="Sikkim">Sikkim</option>
<option value="TN">Tamil Nadu</option>
<option value="Telangana">Telangana</option>
<option value="Tripura">Tripura</option>
<option value="UP">Uttar Pradesh</option>
<option value="Uttarakhand">Uttarakhand</option>
<option value="WB">West Bengal</option>
<option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
<option value="Chandigarh">Chandigarh</option>
<option value="Dadra and Nagar Haveli and Daman and Diu">Dadra and Nagar Haveli and Daman and Diu</option>
<option value="Lakshadweep">Lakshadweep</option>
<option value="Delhi">Delhi</option>
<option value="Puducherry">Puducherry</option>
    </select>
    </div>
    <div>
    <label>Age</label>
    <input ref = {ageInputRef}/>
    </div>
    <div>
    <label>Email</label>
    <input ref = {emailInputRef}/>
    </div>
    <div>
    <label>Password</label>
    <input ref = {passwordInputRef}/>
    </div>
    <div>
    <label>Mobile No</label>
    <input ref = {mobileNoInputRef}/>
    </div>
    <div>
    <label>Profile Pic</label>
    <input ref = {profilePicInputRef} type = "file"/>
    </div>
    <div>
   <button type = "button" onClick={()=>{
    if(selectedGender == "male"){
      salutation = "Mr."

    }else{
      if(maritalStatus == "single"){
        salutation = "Miss."

      }else{
        salutation = "Mrs."

      }
      

    }
    resultParaInputRef.current.innerHTML = `${salutation}${firstNameInputRef.current.value} ${lastNameInputRef.current.value} From ${selectInputRef.current.value},  Your Account Has Been Created Successful`
    resultParaInputRef.current.style.color = "green"
    resultParaInputRef.current.style.fontWeight = "400"
    resultParaInputRef.current.style.fontStyle = "italic"
   }}>Sign Up</button>
    </div>
    <div>
    <p ref = {resultParaInputRef}></p>
    </div>
    </form>
    <div>
    <Link to = "/">Sign In</Link>
    </div>
    </div>
  )
}

export default Signup