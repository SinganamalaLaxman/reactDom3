import logo from './logo.svg';
import './App.css';
import Signup from './components/Signup';
import { BrowserRouter } from 'react-router-dom';

function App() {
  return (
    <div className="App">
     <BrowserRouter>
     <Signup></Signup>
     </BrowserRouter>
     
    </div>
  );
}

export default App;
